# Bookstore.BookApi

All URIs are relative to *https://bookstore.swagger.io/api/v3*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addBook**](BookApi.md#addBook) | **POST** /book | Add a new book to the library
[**deleteBook**](BookApi.md#deleteBook) | **DELETE** /book/{bookId} | Deletes a book
[**findBooksByid**](BookApi.md#findBooksByid) | **GET** /book/findByid | retrieve list of books by id
[**getBookById**](BookApi.md#getBookById) | **GET** /book/{bookId} | Find book by ID
[**updateBook**](BookApi.md#updateBook) | **PUT** /book | Update an existing book in library
[**updateBookWithForm**](BookApi.md#updateBookWithForm) | **POST** /book/{bookId} | Updates a book in the library with form data
[**uploadFile**](BookApi.md#uploadFile) | **POST** /book/{bookId}/uploadImage | uploads an image

<a name="addBook"></a>
# **addBook**
> Book addBook(body, id, title, photoUrls, author, status)

Add a new book to the library

Add a new book to the library

### Example
```javascript
import {Bookstore} from 'bookstore';
let defaultClient = Bookstore.ApiClient.instance;

// Configure OAuth2 access token for authorization: petstore_auth
let petstore_auth = defaultClient.authentications['petstore_auth'];
petstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new Bookstore.BookApi();
let body = new Bookstore.Book(); // Book | Create a new book in the library
let id = 789; // Number | 
let title = "title_example"; // String | 
let photoUrls = null; // Array | 
let author = "author_example"; // String | 
let status = "status_example"; // String | 

apiInstance.addBook(body, id, title, photoUrls, author, status, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Book**](Book.md)| Create a new book in the library | 
 **id** | **Number**|  | 
 **title** | **String**|  | 
 **photoUrls** | [**Array**](.md)|  | 
 **author** | **String**|  | 
 **status** | **String**|  | 

### Return type

[**Book**](Book.md)

### Authorization

[petstore_auth](../README.md#petstore_auth)

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml

<a name="deleteBook"></a>
# **deleteBook**
> deleteBook(bookId, opts)

Deletes a book

delete a book

### Example
```javascript
import {Bookstore} from 'bookstore';
let defaultClient = Bookstore.ApiClient.instance;

// Configure OAuth2 access token for authorization: petstore_auth
let petstore_auth = defaultClient.authentications['petstore_auth'];
petstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new Bookstore.BookApi();
let bookId = 789; // Number | Book id to delete
let opts = { 
  'apiKey': "apiKey_example" // String | 
};
apiInstance.deleteBook(bookId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookId** | **Number**| Book id to delete | 
 **apiKey** | **String**|  | [optional] 

### Return type

null (empty response body)

### Authorization

[petstore_auth](../README.md#petstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="findBooksByid"></a>
# **findBooksByid**
> [Book] findBooksByid(opts)

retrieve list of books by id

Multiple id values can be provided with comma separated strings

### Example
```javascript
import {Bookstore} from 'bookstore';
let defaultClient = Bookstore.ApiClient.instance;

// Configure OAuth2 access token for authorization: petstore_auth
let petstore_auth = defaultClient.authentications['petstore_auth'];
petstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new Bookstore.BookApi();
let opts = { 
  'status': "available" // String | Status values that need to be considered for filter
};
apiInstance.findBooksByid(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **status** | **String**| Status values that need to be considered for filter | [optional] [default to available]

### Return type

[**[Book]**](Book.md)

### Authorization

[petstore_auth](../README.md#petstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getBookById"></a>
# **getBookById**
> Book getBookById(bookId)

Find book by ID

Retrieves a book

### Example
```javascript
import {Bookstore} from 'bookstore';
let defaultClient = Bookstore.ApiClient.instance;

// Configure API key authorization: api_key
let api_key = defaultClient.authentications['api_key'];
api_key.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.apiKeyPrefix = 'Token';

// Configure OAuth2 access token for authorization: petstore_auth
let petstore_auth = defaultClient.authentications['petstore_auth'];
petstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new Bookstore.BookApi();
let bookId = 789; // Number | ID of book to return

apiInstance.getBookById(bookId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookId** | **Number**| ID of book to return | 

### Return type

[**Book**](Book.md)

### Authorization

[api_key](../README.md#api_key), [petstore_auth](../README.md#petstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="updateBook"></a>
# **updateBook**
> Book updateBook(body, id, title, photoUrls, author, status)

Update an existing book in library

Update an existing book by Id

### Example
```javascript
import {Bookstore} from 'bookstore';
let defaultClient = Bookstore.ApiClient.instance;

// Configure OAuth2 access token for authorization: petstore_auth
let petstore_auth = defaultClient.authentications['petstore_auth'];
petstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new Bookstore.BookApi();
let body = new Bookstore.Book(); // Book | Update an existent book in the library
let id = 789; // Number | 
let title = "title_example"; // String | 
let photoUrls = null; // Array | 
let author = "author_example"; // String | 
let status = "status_example"; // String | 

apiInstance.updateBook(body, id, title, photoUrls, author, status, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Book**](Book.md)| Update an existent book in the library | 
 **id** | **Number**|  | 
 **title** | **String**|  | 
 **photoUrls** | [**Array**](.md)|  | 
 **author** | **String**|  | 
 **status** | **String**|  | 

### Return type

[**Book**](Book.md)

### Authorization

[petstore_auth](../README.md#petstore_auth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml

<a name="updateBookWithForm"></a>
# **updateBookWithForm**
> updateBookWithForm(bookId, opts)

Updates a book in the library with form data

### Example
```javascript
import {Bookstore} from 'bookstore';
let defaultClient = Bookstore.ApiClient.instance;

// Configure OAuth2 access token for authorization: petstore_auth
let petstore_auth = defaultClient.authentications['petstore_auth'];
petstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new Bookstore.BookApi();
let bookId = 789; // Number | ID of book that needs to be updated
let opts = { 
  'name': "name_example", // String | Name of pet that needs to be updated
  'status': "status_example" // String | Status of pet that needs to be updated
};
apiInstance.updateBookWithForm(bookId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookId** | **Number**| ID of book that needs to be updated | 
 **name** | **String**| Name of pet that needs to be updated | [optional] 
 **status** | **String**| Status of pet that needs to be updated | [optional] 

### Return type

null (empty response body)

### Authorization

[petstore_auth](../README.md#petstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="uploadFile"></a>
# **uploadFile**
> ApiResponse uploadFile(bookId, opts)

uploads an image

### Example
```javascript
import {Bookstore} from 'bookstore';
let defaultClient = Bookstore.ApiClient.instance;

// Configure OAuth2 access token for authorization: petstore_auth
let petstore_auth = defaultClient.authentications['petstore_auth'];
petstore_auth.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new Bookstore.BookApi();
let bookId = 789; // Number | ID of book to update
let opts = { 
  'body': null, // Object | 
  'additionalMetadata': "additionalMetadata_example" // String | Additional Metadata
};
apiInstance.uploadFile(bookId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **bookId** | **Number**| ID of book to update | 
 **body** | [**Object**](Object.md)|  | [optional] 
 **additionalMetadata** | **String**| Additional Metadata | [optional] 

### Return type

[**ApiResponse**](ApiResponse.md)

### Authorization

[petstore_auth](../README.md#petstore_auth)

### HTTP request headers

 - **Content-Type**: application/octet-stream
 - **Accept**: application/json

