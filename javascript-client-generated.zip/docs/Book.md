# Bookstore.Book

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**title** | **String** |  | [optional] 
**photoUrls** | **Array** |  | 
**author** | **String** |  | [optional] 
**status** | **String** | book status in the store | [optional] 

<a name="StatusEnum"></a>
## Enum: StatusEnum

* `available` (value: `"available"`)
* `sold` (value: `"sold"`)

